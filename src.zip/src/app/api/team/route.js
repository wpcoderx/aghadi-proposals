import User from "@/models/User";
import dbConnect from "@/lib/dbConnect";
import { NextResponse } from "next/server";

export async function GET(){

    await dbConnect();

    try{

        const user = User.find({});

        return NextResponse.json({success:true,message:"worked",data:user},{status:201});

    }catch(error){

        return NextResponse.json({success:false,message:"error"},{status:400});
    }


}