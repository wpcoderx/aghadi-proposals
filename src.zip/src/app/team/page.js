"use client";

import { useSession } from "next-auth/react";
import { redirect } from "next/navigation";
import { useEffect } from "react";
import { FaLock } from "react-icons/fa";

export default function Team() {
  const { data: session, status } = useSession();

  useEffect(() => {

    if (status === "unauthenticated") {
      redirect("/login");
    }
  }, [status]);

  useEffect(() => {

    /* const data = await fetch('/api/team/');

    console.log(data.json); */

  }, []);

  if (status === "loading" || !session) return null;

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 dark:bg-gray-900 px-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8 w-full max-w-md">
        <h2 className="text-2xl font-semibold text-center mb-6 text-gray-800 dark:text-white flex items-center justify-center gap-2">
          <FaLock /> All Members 
        </h2>
      </div>
    </div>
  );
}
