import { authGuard } from "@/lib/authGuard";
import { useEffect, useState } from "react";

// ✅ This component is server-rendered (default in App Router)
const DashboardPage = async () => {
  const session = await authGuard(); // ✅ run on server

  return (
    <div className="min-h-screen bg-gray-100 p-6 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-800 dark:text-white">
            Dashboard
          </h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Overview of recent data
          </p>
        </div>

        {/* ✅ Use client-specific logic inside this */}
        <ContactTable />
      </div>
    </div>
  );
};

export default DashboardPage;

// ✅ This part runs on client (inside same file)
"use client";
function ContactTable() {
  const [contact, setContact] = useState([]);

  useEffect(() => {
    fetch_contact();
  }, []);

  const fetch_contact = async () => {
    try {
      const res = await fetch("/api/contact");
      if (!res.ok) throw new Error("Data not found...");
      const emaillist = await res.json();
      setContact(emaillist.data);
    } catch (err) {
      console.error("Error loading contacts:", err);
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 shadow rounded-2xl p-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-gray-700 dark:text-gray-100">
          Contact Submissions
        </h2>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full border border-gray-200 text-sm text-left dark:border-gray-600">
          <thead className="bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 uppercase">
            <tr>
              <th className="px-6 py-3 border-b">#</th>
              <th className="px-6 py-3 border-b">Name</th>
              <th className="px-6 py-3 border-b">Email</th>
              <th className="px-6 py-3 border-b">Message</th>
              <th className="px-6 py-3 border-b">Date</th>
              <th className="px-6 py-3 border-b text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200">
            {contact.map((item, index) => (
              <tr
                key={item._id}
                className="hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                <td className="px-6 py-4 border-b">{index + 1}</td>
                <td className="px-6 py-4 border-b font-medium">
                  {item.contactName}
                </td>
                <td className="px-6 py-4 border-b">
                  <a
                    href={`mailto:${item.contactEmail}`}
                    className="text-blue-600 hover:underline"
                  >
                    {item.contactEmail}
                  </a>
                </td>
                <td className="px-6 py-4 border-b">
                  <span className="px-2 py-1 text-xs bg-green-100 text-green-800 rounded">
                    {item.contactMessage}
                  </span>
                </td>
                <td className="px-6 py-4 border-b">
                  <span className="px-2 py-1">
                    {new Date(item.createdAt).getDate()}/
                    {new Date(item.createdAt).getMonth() + 1}/
                    {new Date(item.createdAt).getFullYear()}
                  </span>
                </td>
                <td className="px-6 py-4 border-b text-right space-x-2">
                  <button className="text-blue-600 hover:underline">
                    Edit
                  </button>
                  <button className="text-red-600 hover:underline">
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
